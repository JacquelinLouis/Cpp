Pour executer ce programme (sous linux):
-Allez dans le dossier "Devoir1"
-Compilez le avec la commande "make main"
	-Vous devrez peut être installer g++ via la commande "sudo apt-get install g++"
-Verifiez que les fichiers "FP.txt" et "FT.txt" sont presents dans le dossier
-Executez le main avec la commande "./main"
-Observez le resultat et verifiez le fichier "FP.txt" s'il devait etre modifie par les instructions du "FT.txt"
-Vous pouvez restorer le FP.txt en le copiant a partir du fichier FP_save.txt

Vous pouvez me contacter sur le mail : jacquelinlouis@gmail.com si je peux vous renseigner sur mon programme.

||||||||||||||
|   _ 	 _   |
|   .    .   |
|            |
\   \___/    /
 \_________ /
